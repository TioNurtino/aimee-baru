import images from "./images";

export const photos = [
    images.photo1,
    images.photo2,
    images.photo3,
    images.photo4,
    images.photo5,
    images.photo6,
]

export const imagesDataURL = [
    'https://i.ibb.co/W29btXp/profile.jpg'
]